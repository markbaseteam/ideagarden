Models help with
[[Segregation models]]

1. Real time decision aids
2. Comparative statics
3. Counterfactuals
4. Identify and rank levers
5. Experimental Design

1. Real time decision aids
2. Comparative statics
3. Counterfactuals
4. Identify and rank levers
5. Experimental Design
1. Real time decision aids
2. Comparative statics
3. Counterfactuals
4. Identify and rank levers
5. Experimental Design
1. Real time decision aids
2. Comparative statics
3. Counterfactuals
4. Identify and rank levers
5. Experimental Design
1. Real time decision aids
2. Comparative statics
3. Counterfactuals
4. Identify and rank levers
5. Experimental Design
1. Real time decision aids
2. Comparative statics
3. Counterfactuals
4. Identify and rank levers
5. Experimental Design
1. Real time decision aids
2. Comparative statics
3. Counterfactuals
4. Identify and rank levers
5. Experimental Design
1. Real time decision aids
2. Comparative statics
3. Counterfactuals
4. Identify and rank levers
5. Experimental Design
1. Real time decision aids
2. Comparative statics
3. Counterfactuals
4. Identify and rank levers
5. Experimental Design
1. Real time decision aids
2. Comparative statics
3. Counterfactuals
4. Identify and rank levers
5. Experimental Design
1. Real time decision aids
2. Comparative statics
3. Counterfactuals
4. Identify and rank levers
5. Experimental Design
1. Real time decision aids
2. Comparative statics
3. Counterfactuals
4. Identify and rank levers
5. Experimental Design
1. Real time decision aids
2. Comparative statics
3. Counterfactuals
4. Identify and rank levers
5. Experimental Design
1. Real time decision aids
2. Comparative statics
3. Counterfactuals
4. Identify and rank levers
5. Experimental Design
1. Real time decision aids
2. Comparative statics
3. Counterfactuals
4. Identify and rank levers
5. Experimental Design
1. Real time decision aids
2. Comparative statics
3. Counterfactuals
4. Identify and rank levers
5. Experimental Design
1. Real time decision aids
2. Comparative statics
3. Counterfactuals
4. Identify and rank levers
5. Experimental Design
1. Real time decision aids
2. Comparative statics
3. Counterfactuals
4. Identify and rank levers
5. Experimental Design
1. Real time decision aids
2. Comparative statics
3. Counterfactuals
4. Identify and rank levers
5. Experimental Design
1. Real time decision aids
2. Comparative statics
3. Counterfactuals
4. Identify and rank levers
5. Experimental Design
1. Real time decision aids
2. Comparative statics
3. Counterfactuals
4. Identify and rank levers
5. Experimental Design
1. Real time decision aids
2. Comparative statics
3. Counterfactuals
4. Identify and rank levers
5. Experimental Design
1. Real time decision aids
2. Comparative statics
3. Counterfactuals
4. Identify and rank levers
5. Experimental Design
1. Real time decision aids
2. Comparative statics
3. Counterfactuals
4. Identify and rank levers
5. Experimental Design
1. Real time decision aids
2. Comparative statics
3. Counterfactuals
4. Identify and rank levers
5. Experimental Design
1. Real time decision aids
2. Comparative statics
3. Counterfactuals
4. Identify and rank levers
5. Experimental Design
1. Real time decision aids
2. Comparative statics
3. Counterfactuals
4. Identify and rank levers
5. Experimental Design
1. Real time decision aids
2. Comparative statics
3. Counterfactuals
4. Identify and rank levers
5. Experimental Design
1. Real time decision aids
2. Comparative statics
3. Counterfactuals
4. Identify and rank levers
5. Experimental Design
1. Real time decision aids
2. Comparative statics
3. Counterfactuals
4. Identify and rank levers
5. Experimental Design
1. Real time decision aids
2. Comparative statics
3. Counterfactuals
4. Identify and rank levers
5. Experimental Design
1. Real time decision aids
2. Comparative statics
3. Counterfactuals
4. Identify and rank levers
5. Experimental Design
1. Real time decision aids
2. Comparative statics
3. Counterfactuals
4. Identify and rank levers
5. Experimental Design
1. Real time decision aids
2. Comparative statics
3. Counterfactuals
4. Identify and rank levers
5. Experimental Design
1. Real time decision aids
2. Comparative statics
3. Counterfactuals
4. Identify and rank levers
5. Experimental Design
1. Real time decision aids
2. Comparative statics
3. Counterfactuals
4. Identify and rank levers
5. Experimental Design
1. Real time decision aids
2. Comparative statics
3. Counterfactuals
4. Identify and rank levers
5. Experimental Design
1. Real time decision aids
2. Comparative statics
3. Counterfactuals
4. Identify and rank levers
5. Experimental Design
1. Real time decision aids
2. Comparative statics
3. Counterfactuals
4. Identify and rank levers
5. Experimental Design
1. Real time decision aids
2. Comparative statics
3. Counterfactuals
4. Identify and rank levers
5. Experimental Design
1. Real time decision aids
2. Comparative statics
3. Counterfactuals
4. Identify and rank levers
5. Experimental Design
1. Real time decision aids
2. Comparative statics
3. Counterfactuals
4. Identify and rank levers
5. Experimental Design
1. Real time decision aids
2. Comparative statics
3. Counterfactuals
4. Identify and rank levers
5. Experimental Design
1. Real time decision aids
2. Comparative statics
3. Counterfactuals
4. Identify and rank levers
5. Experimental Design
1. Real time decision aids
2. Comparative statics
3. Counterfactuals
4. Identify and rank levers
5. Experimental Design
1. Real time decision aids
2. Comparative statics
3. Counterfactuals
4. Identify and rank levers
5. Experimental Design

