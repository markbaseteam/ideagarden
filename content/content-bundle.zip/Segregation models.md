
Choosing a group - People choose to associate people who look, act alike.
Acting like a group - People act like the group to increase their belonging


